'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  MessageCircle,
  User,
  Users,
  Home,
  Send,
  Bell,
  Settings,
  HelpCircle,
  LogOut,
} from 'lucide-react';
import { SidebarItem } from './SidebarItem';
import { DarkModeToggle } from './DarkModeToggle';
import { useAuthStore } from '../../store/auth';
import { useLanguage } from '../language-provider';
import { useNotificationsStore } from '../../store/notifications';
import { useChatActivityStore } from '../../store/chat-activity';
import { api } from '../../lib/api';

type SidebarProps = {
  isOpen?: boolean;
  onClose?: () => void;
};

export function Sidebar({ isOpen = true, onClose }: SidebarProps) {
  const router = useRouter();
  const logout = useAuthStore((s) => s.logout);
  const accessToken = useAuthStore((s) => s.accessToken);
  const { language } = useLanguage();
  const unreadNotifications = useNotificationsStore((s) => s.items.filter((item) => !item.read).length);
  const unreadDirectIds = useChatActivityStore((s) => s.unreadDirectIds);
  const unreadRoomIds = useChatActivityStore((s) => s.unreadRoomIds);
  const unreadChatsCount = unreadDirectIds.length + unreadRoomIds.length;

  const [pendingContacts, setPendingContacts] = useState(0);

  useEffect(() => {
    if (!accessToken) {
      setPendingContacts(0);
      return;
    }
    let cancelled = false;
    void api<{ id: string }[]>('/connections/requests', { method: 'GET' })
      .then((list) => {
        if (!cancelled) setPendingContacts(Array.isArray(list) ? list.length : 0);
      })
      .catch(() => {
        if (!cancelled) setPendingContacts(0);
      });
    return () => {
      cancelled = true;
    };
  }, [accessToken]);

  const menu = [
    { icon: MessageCircle, label: language === 'en' ? 'Chats' : 'Чаты', path: '/dashboard', badge: unreadChatsCount, highlight: unreadChatsCount > 0 },
    { icon: Users, label: language === 'en' ? 'Contacts' : 'Контакты', path: '/contacts', badge: pendingContacts, highlight: pendingContacts > 0 },
    { icon: User, label: language === 'en' ? 'Profile' : 'Профиль', path: '/profile' },
    { icon: Home, label: language === 'en' ? 'Rooms' : 'Комнаты', path: '/rooms', badge: unreadRoomIds.length, highlight: unreadRoomIds.length > 0 },
    { icon: Send, label: language === 'en' ? 'Invites' : 'Приглашения', path: '/invites' },
    { icon: Bell, label: language === 'en' ? 'Notifications' : 'Уведомления', path: '/notifications', badge: unreadNotifications, highlight: unreadNotifications > 0 },
    { icon: Settings, label: language === 'en' ? 'Settings' : 'Настройки', path: '/settings' },
  ];

  const handleLogout = () => {
    logout();
    router.replace('/');
    onClose?.();
  };

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside
        className={`
          fixed left-0 top-0 z-50 flex h-full w-[280px] flex-col
          border-r border-slate-200 bg-gradient-to-b from-white to-slate-50
          shadow-[4px_0_24px_-4px_rgba(148,163,184,0.22)]
          transition-transform duration-300 ease-in-out
          dark:border-slate-700/50 dark:bg-gradient-to-b dark:from-slate-900 dark:to-slate-950 dark:shadow-[4px_0_24px_-4px_rgba(0,0,0,0.3)]
          lg:translate-x-0
          ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        <div className="flex h-full flex-col p-4">
          {/* Logo */}
          <Link
            href="/"
            className="mb-6 flex items-center gap-2 rounded-xl px-3 py-2.5 transition hover:bg-slate-900/5 dark:hover:bg-white/5"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-indigo-500 text-white shadow-lg shadow-blue-500/30">
              <span className="text-sm font-bold">CX</span>
            </div>
            <span className="text-lg font-semibold text-slate-900 dark:text-white">CONNEXY</span>
          </Link>

          {/* Navigation */}
          <nav className="flex-1 space-y-1">
            {menu.map((item) => (
              <SidebarItem
                key={item.path + item.label}
                icon={item.icon}
                label={item.label}
                path={item.path}
                badge={item.badge}
                highlight={item.highlight}
              />
            ))}
          </nav>

          {/* Dark Mode */}
          <div className="mt-4 rounded-xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-600/50 dark:bg-slate-800/30">
            <DarkModeToggle />
          </div>

          {/* Help */}
          <Link
            href="/help"
            className="mt-3 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-600 transition hover:bg-slate-900/5 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-white/5 dark:hover:text-slate-200"
          >
            <HelpCircle className="h-5 w-5 shrink-0" />
            {language === 'en' ? 'Help & Support' : 'Помощь'}
          </Link>

          {/* Logout */}
          <button
            type="button"
            onClick={handleLogout}
            className="mt-2 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-red-400 transition hover:bg-red-500/10 hover:text-red-300"
          >
            <LogOut className="h-5 w-5 shrink-0" />
            {language === 'en' ? 'Log out' : 'Выйти'}
          </button>
        </div>
      </aside>
    </>
  );
}
