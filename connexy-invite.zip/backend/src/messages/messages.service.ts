import { Injectable, ForbiddenException, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service.js';
import { mapMessagesText, prepareMessageForApi, prepareMessageForStorage } from '../security/message-encryption.util.js';
import { ChatGateway } from '../chat/chat.gateway.js';

@Injectable()
export class MessagesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly chatGateway: ChatGateway,
  ) {}

  async getThread(currentUserId: string, peerId: string) {
    if (!peerId) throw new BadRequestException('peerId is required');
    const rows = await this.prisma.message.findMany({
      where: {
        OR: [
          { senderId: currentUserId, recipientId: peerId },
          { senderId: peerId, recipientId: currentUserId },
        ],
      },
      orderBy: { createdAt: 'asc' },
      take: 200,
    });
    return mapMessagesText(rows);
  }

  async send(
    currentUserId: string,
    to: string,
    text: string,
    attachment?: { url?: string; name?: string; type?: string },
  ) {
    const hasText = text.trim().length > 0;
    const hasAttachment = !!attachment?.url;
    if (!hasText && !hasAttachment) throw new BadRequestException('Text or attachment required');
    if (currentUserId === to) throw new ForbiddenException('Cannot message yourself');
    const recipient = await this.prisma.user.findUnique({ where: { id: to } });
    if (!recipient) throw new BadRequestException('Recipient not found');
    const row = await this.prisma.message.create({
      data: {
        senderId: currentUserId,
        recipientId: to,
        text: hasText ? prepareMessageForStorage(text.trim()) : '',
        attachmentUrl: attachment?.url ?? null,
        attachmentName: attachment?.name ?? null,
        attachmentType: attachment?.type ?? null,
      },
    });

    // Эмитим событие получателю в реальном времени
    const messageForClient = { ...row, text: prepareMessageForApi(row.text) };
    this.chatGateway.sendToUser(to, 'newDirectMessage', {
      ...messageForClient,
      text: text.trim(),
    });

    return messageForClient;
  }

  async remove(currentUserId: string, messageId: string) {
    const message = await this.prisma.message.findUnique({
      where: { id: messageId },
      select: { id: true, senderId: true, recipientId: true },
    });

    if (!message) throw new NotFoundException('Сообщение не найдено');
    if (message.senderId !== currentUserId && message.recipientId !== currentUserId) {
      throw new ForbiddenException('Нет доступа к удалению сообщения');
    }

    await this.prisma.message.delete({ where: { id: messageId } });
    return { ok: true };
  }
}
